import pymysql

# 侯数据库
conn = pymysql.connect(host='localhost', port=3306,
                       user='root', passwd='123456',
                       db='学校公共资源预约管理系统', charset='utf8')

# #龙数据库
# conn = pymysql.connect(host='localhost', port=3306,
#                        user='root', passwd='18776763673l',
#                        db='test_db', charset='utf8')


def conn_mysql(sql_code):
    """
    连接数据库并执行传入的 MySQL 语句。

    :param sql_code: 要执行的 MySQL 语句字符串
    :return: 如果是查询语句，返回查询结果列表；如果是非查询语句，返回受影响的行数
    """
    try:
        # 检查数据库连接是否仍然有效，如果连接断开则尝试重新连接。
        # reconnect=True 参数表示当连接失效时，自动尝试重新建立连接。
        conn.ping(reconnect=True)
        # 创建游标对象，设置为字典游标，返回结果为字典格式
        with conn.cursor(pymysql.cursors.DictCursor) as cursor:
            # 执行 SQL 语句
            cursor.execute(sql_code)
            if sql_code.strip().lower().startswith('select'):
                # 如果是查询语句，获取查询结果
                result = cursor.fetchall()
                return result
            else:
                # 如果是非查询语句，提交事务并返回受影响的行数
                conn.commit()
                return cursor.rowcount
    except Exception as e:
        # 出现异常时回滚事务
        conn.rollback()
        print(f"执行 SQL 语句时出错: {e}")
        return None

if __name__ == '__main__':
    # code = "INSERT INTO Users(Username, Password, user_type) VALUES ('侯耀辉', '123456', 'student')"

    # print(conn_mysql(code))
    # code1 = "SELECT * FROM resource_categories ORDER BY category_id"
    print("=== 资源类别 ===")
    code1 = "SELECT * FROM resource_categories ORDER BY category_id"
    
    # name = "HouYaohui"
    # code2 = f"SELECT * FROM Users WHERE username = '{name}'"

    # print(conn_mysql(code2))

    #查看资源类别