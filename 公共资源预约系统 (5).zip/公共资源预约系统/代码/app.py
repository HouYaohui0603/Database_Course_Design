from flask import Flask, render_template, request, flash, redirect, url_for
from flask import jsonify
from flask import session
import datetime
from connect import *

app = Flask(__name__)
# 设置密钥
app.secret_key = '123456'


# 首页
@app.route("/")
def index_login():
    return render_template("login.html")


# 注册
@app.route("/register")
def index_register():
    return render_template("register.html")


# 管理员功能界面
@app.route("/admin_dashboard")
def index_admin_dashboard():
    return render_template("admin_dashboard.html")


# 老师用户功能界面
@app.route("/teacher_dashboard")
def index_teacher_dashboard():
    return render_template("teacher_dashboard.html")


# 学生用户功能界面
@app.route("/student_dashboard")
def index_student_dashboard():
    return render_template("student_dashboard.html")


# mysql语句执行界面
@app.route("/execute_mysql")
def index_execute_mysql():
    return render_template("execute_mysql.html")


# 注销界面
@app.route("/close_account")
def index_close_account():
    return render_template("close_account.html")


# # 添加资源类别界面
# @app.route("/manage_category")
# def index_add_category():
#     return render_template("manage_category.html")

# 预约验证页面 
@app.route('/booking_verify', methods=['GET', 'POST'])
def booking_verify():
    if request.method == 'GET':
        # 从URL参数获取资源名称
        resource_name = request.args.get('resource_name')

        if not resource_name:
            flash('预约信息缺失，请重新选择资源', 'error')
            return redirect(url_for('booking_page'))

        # 查询资源信息
        resource_code = f"SELECT r.*, rc.category_name FROM resources r " \
                        f"LEFT JOIN resource_categories rc ON r.category_id = rc.category_id " \
                        f"WHERE r.resource_name = '{resource_name}'"
        resource_ans = conn_mysql(resource_code)

        if not resource_ans:
            flash('资源不存在或已被删除', 'error')
            return redirect(url_for('booking_page'))

        resource = resource_ans[0]

        # 检查资源状态
        if resource['status'] != 'available':
            flash('该资源当前不可预约', 'error')
            return redirect(url_for('booking_page'))

        return render_template('booking_verify.html', resource=resource)

    elif request.method == 'POST':
        # 获取表单数据
        username = request.form.get('username')
        password = request.form.get('password')
        resource_name = request.form.get('resource_name')

        # 参数验证
        if not all([username, password, resource_name]):
            flash('请填写完整信息', 'error')
            return redirect(url_for('booking_verify', resource_name=resource_name))

        # 验证用户身份
        user_code = f"SELECT * FROM users WHERE username = '{username}'"
        user_ans = conn_mysql(user_code)

        if not user_ans:
            flash('用户名不存在', 'error')
            return redirect(url_for('booking_verify', resource_name=resource_name))

        user = user_ans[0]
        if password != user['password'] or user['status'] != 'active':
            flash('密码错误或账户已禁用', 'error')
            return redirect(url_for('booking_verify', resource_name=resource_name))

        # 验证资源可用性
        resource_code = f"SELECT * FROM resources WHERE resource_name = '{resource_name}'"
        resource_ans = conn_mysql(resource_code)

        if not resource_ans:
            flash('资源不存在', 'error')
            return redirect(url_for('booking_page'))

        resource = resource_ans[0]
        if resource['status'] != 'available':
            flash('该资源当前不可预约', 'error')
            return redirect(url_for('booking_page'))

        # 创建预约记录
        user_id = user['user_id']
        resource_id = resource['resource_id']

        # 获取当前日期时间
        now = datetime.datetime.now()
        booking_date = now.strftime('%Y-%m-%d')

        # 构建预约SQL（默认预约当前日期的下一个小时）
        start_time = now.strftime('%H:00:00')
        # 计算结束时间（当前时间+1小时）
        end_time = (now + datetime.timedelta(hours=1)).strftime('%H:00:00')

        booking_code = f"""
        INSERT INTO bookings (
            resource_id, user_id, booking_date, 
            start_time, end_time, booking_status, booking_time
        ) VALUES (
            {resource_id}, {user_id}, '{booking_date}', 
            '{start_time}', '{end_time}', 'confirmed', NOW()
        )
        """

        # 执行预约操作
        result = conn_mysql(booking_code)

        if not result:
            flash('预约失败，请稍后重试', 'error')
            return redirect(url_for('booking_verify', resource_name=resource_name))

        # 更新资源状态
        update_code = f"""
        UPDATE resources 
        SET status = 'occupied' 
        WHERE resource_id = {resource_id}
        """
        conn_mysql(update_code)

        flash('预约成功！', 'success')
        return redirect(url_for('booking_success'))


# 登录验证
@app.route("/login", methods=['POST'])
def login():
    name = request.form.get("username")
    pwd = request.form.get("password")
    code = f"SELECT * FROM users WHERE UserName = '{name}'"
    ans = conn_mysql(code)
    if len(ans) > 0:
        ans = ans[0]
        if pwd == ans['password'] and ans['status'] == 'active':
            # 获取账户类型
            user_kind = ans['user_type']
            session['username'] = name  # 将用户名存储在会话中
            session['user_type'] = user_kind  # 将账户类型存储在会话中
            if user_kind == 'admin':  # 假设管理员类型为 admin
                return jsonify({
                    "success": True,
                    "redirect_url": url_for('index_admin_dashboard')
                })
            elif user_kind == 'teacher':  # 老师用户类型为 teacher
                return jsonify({
                    "success": True,
                    "redirect_url": url_for('index_teacher_dashboard')
                })
            elif user_kind == 'student':  # 学生用户类型为 student
                return jsonify({
                    "success": True,
                    "redirect_url": url_for('index_student_dashboard')
                })
            else:
                return jsonify({
                    "success": False,
                    "message": "未知账户类型，请联系管理员"
                })
        else:
            return jsonify({
                "success": False,
                "message": '密码错误'
            })
    else:
        return jsonify({
            "success": False,
            "message": '用户名不存在，请注册'
        })


# 注册功能
@app.route("/register", methods=['POST'])
def register():
    name = request.form.get("username")
    pwd = request.form.get("password")
    confirm_pwd = request.form.get("confirm_password")
    user_type = request.form.get("user_type")
    check_code = f"SELECT * FROM Users WHERE UserName = '{name}'"
    ans = conn_mysql(check_code)
    if len(ans) > 0:
        return '用户名已存在，请登录 <a href="/">返回登录</a>'
    else:
        if name and pwd:
            if pwd != confirm_pwd:
                return '两次密码不一致，请重新输入 <a href="/register">返回注册</a>'
            else:
                try:
                    # 使用参数化查询插入用户信息
                    insert_code = f"INSERT INTO Users(Username, Password, user_type) VALUES ('{name}', '{pwd}', '{user_type}')"
                    conn_mysql(insert_code)
                    return '注册成功，请登录 <a href="/">返回登录</a>'
                except Exception as e:
                    # 处理数据库插入异常
                    print(f"数据库插入错误: {e}")
                    return '注册失败，请稍后重试 <a href="/register">返回注册</a>'
        else:
            return '用户名或密码不能为空 <a href="/register">返回注册</a>'


# mysql语句执行
@app.route("/execute_mysql", methods=['POST'])
def execute_mysql():
    # 获取用户输入的 SQL 语句
    code = request.form.get("statement")

    # 检查 SQL 语句是否为空
    if not code:
        return "SQL 语句不能为空，请重新输入 <a href='/execute_mysql'>返回输入 MySQL 语句</a>"

    try:
        # 执行 SQL 语句
        ans = conn_mysql(code)

        if isinstance(ans, list) and ans:  # 假设查询结果为非空列表
            # 生成 HTML 表格表头
            table_html = "<table><tr>"
            for key in ans[0].keys():
                table_html += f"<th>{key}</th>"
            table_html += "</tr>"

            # 生成 HTML 表格内容
            for row in ans:
                table_html += "<tr>"
                for value in row.values():
                    table_html += f"<td>{value}</td>"
                table_html += "</tr>"
            table_html += "</table>"
            result_msg = f"查询成功，结果如下：<br>{table_html}"
        else:
            result_msg = "操作成功。"

        # 渲染模板并传递参数
        return render_template('sql_result.html',
                               result_msg=result_msg
                               )
    except Exception as e:
        # 处理数据库执行异常
        print(f"执行 SQL 语句时出错: {e}")
        return render_template('sql_error.html',
                               error_msg=str(e)
                               )


# 完善个人信息
@app.route("/complete_info", methods=['GET', 'POST'])
def complete_info():
    code = f"SELECT * FROM users WHERE UserName = '{session['username']}'"
    ans = conn_mysql(code)
    user_info = {}
    if len(ans) > 0:
        ans = ans[0]
        user_info = {
            'real_name': ans['real_name'],
            'contact_phone': ans['contact_phone'],
            'email': ans['email']
        }
    if request.method == 'POST':
        # 处理表单数据
        real_name = request.form.get("real_name")
        contact_phone = request.form.get("contact_phone")
        email = request.form.get("email")
        referer = request.form.get("referer")

        # 更新数据库
        update_code = f"UPDATE users SET real_name = '{real_name}', contact_phone = '{contact_phone}', email = '{email}' WHERE UserName = '{session['username']}'"
        try:
            conn_mysql(update_code)
        except Exception as e:
            print(f"更新数据库时出错: {e}")
            return "更新失败，请稍后重试"

        # 操作完成后跳转回来源页面
        if referer:
            return redirect(referer)
        else:
            # 如果没有来源页面，跳转到默认页面
            return redirect(url_for('/'))
    return render_template("complete_info.html", user_info=user_info)


# 注销账户
@app.route("/close_account", methods=['POST'])
def close_account():
    # 获取当前登录用户的用户名
    username = session.get('username')
    if username:
        # 执行 SQL 语句更新用户状态为 'inactive'
        update_code = f"UPDATE users SET status = 'inactive' WHERE UserName = '{username}'"
        try:
            conn_mysql(update_code)
            # 清除会话中的用户信息
            session.pop('username', None)
            return "账户已注销，请重新登录 <a href='/'>返回登录</a>"
        except Exception as e:
            print(f"注销账户时出错: {e}")
            return "注销失败，请稍后重试"
    else:
        return "用户未登录"


# 添加资源类别
@app.route("/manage_category", methods=['POST', 'GET'])
def manage_category():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    try:
        sql = "SELECT * FROM resource_categories ORDER BY category_id"
        print("执行 SQL 查询:", sql)  # 添加日志，打印执行的 SQL 语句
        categories = conn_mysql(sql)
        print("查询结果:", categories)  # 添加日志，打印查询结果
        if not categories:
            print("未查询到资源类别信息")
        return render_template('manage_category.html', categories=categories)
    except Exception as e:
        print(f"查询资源类别信息时出错: {e}")
        return "查询资源类别信息时出错，请稍后重试", 500


@app.route('/manage_category/add', methods=['POST'])
def add_category():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    category_name = request.form.get('category_name')
    description = request.form.get('description')
    if not category_name:
        return "资源类别名称不能为空 <a href='/manage_category'>返回</a>", 400
    try:
        insert_sql = f"INSERT INTO resource_categories (category_name, description) VALUES ('%s', '%s')" % (category_name,
                                                                                                        description)
        conn_mysql(insert_sql)
        return redirect(url_for('manage_category'))
    except Exception as e:
        print(f"添加资源类别时出错: {e}")
        return "添加资源类别失败，请稍后重试", 500


@app.route('/manage_category/delete/<int:category_id>')
def delete_category(category_id):
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    try:
        # 检查该类别下是否有资源
        check_sql = f"SELECT * FROM resources WHERE category_id = %s" % (category_id,)
        resources = conn_mysql(check_sql)
        if resources:
            return "该类别下存在资源，无法删除 <a href='/manage_category'>返回</a>", 400
        delete_sql = f"DELETE FROM resource_categories WHERE category_id = %s" % (category_id,)
        conn_mysql(delete_sql)
        return redirect(url_for('manage_category'))
    except Exception as e:
        print(f"删除资源类别时出错: {e}")
        return "删除资源类别失败，请稍后重试", 500


@app.route('/manage_category/update', methods=['POST'])
def update_category():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    category_id = request.form.get('category_id')
    category_name = request.form.get('category_name')
    description = request.form.get('description')
    if not category_name:
        return "资源类别名称不能为空 <a href='/manage_category'>返回</a>", 400
    try:
        update_sql = f"UPDATE resource_categories SET category_name = '%s', description = '%s' WHERE category_id = %s" % (
            category_name, description, category_id)
        conn_mysql(update_sql)
        return redirect(url_for('manage_category'))
    except Exception as e:
        print(f"修改资源类别信息时出错: {e}")
        return "修改资源类别信息失败，请稍后重试", 500


@app.route('/manage_resource')
def manage_resource():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    try:
        sql = "SELECT r.*, rc.category_name FROM resources r JOIN resource_categories rc ON r.category_id = rc.category_id"
        resources = conn_mysql(sql)
        category_sql = "SELECT * FROM resource_categories"
        categories = conn_mysql(category_sql)
        return render_template('manage_resource.html', resources=resources, categories=categories)
    except Exception as e:
        print(f"查询资源信息时出错: {e}")
        return "查询资源信息时出错，请稍后重试", 500


@app.route('/manage_resource/add', methods=['POST'])
def add_resource():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    resource_name = request.form.get('resource_name')
    category_id = request.form.get('category_id')
    location = request.form.get('location')
    capacity = request.form.get('capacity')
    description = request.form.get('description')
    if not all([resource_name, category_id, location]):
        return "资源名称、类别和位置不能为空 <a href='/manage_resource'>返回</a>", 400
    try:
        insert_sql = f"INSERT INTO resources (resource_name, category_id, location, capacity, description) VALUES ('%s', %s, '%s', %s, '%s')" % (
            resource_name, category_id, location, capacity, description)
        print(insert_sql)
        conn_mysql(insert_sql)
        return redirect(url_for('manage_resource'))
    except Exception as e:
        print(f"添加资源时出错: {e}")
        return "添加资源失败，请稍后重试", 500


@app.route('/manage_resource/delete/<int:resource_id>')
def delete_resource(resource_id):
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    try:
        # 检查该资源是否有预约记录
        check_sql = f"SELECT * FROM bookings WHERE resource_id = %s" % (resource_id,)
        bookings = conn_mysql(check_sql)
        if bookings:
            return "该资源存在预约记录，无法删除 <a href='/manage_resource'>返回</a>", 400
        delete_sql = f"DELETE FROM resources WHERE resource_id = %s" % (resource_id,)
        conn_mysql(delete_sql)
        return redirect(url_for('manage_resource'))
    except Exception as e:
        print(f"删除资源时出错: {e}")
        return "删除资源失败，请稍后重试", 500


@app.route('/manage_resource/update', methods=['POST'])
def update_resource():
    if 'username' not in session or session.get('user_type') != 'admin':
        return redirect(url_for('login'))
    resource_id = request.form.get('resource_id')
    resource_name = request.form.get('resource_name')
    category_id = request.form.get('category_id')
    location = request.form.get('location')
    capacity = request.form.get('capacity')
    description = request.form.get('description')
    if not all([resource_name, category_id, location]):
        return "资源名称、类别和位置不能为空 <a href='/manage_resource'>返回</a>", 400
    try:
        update_sql = f"UPDATE resources SET resource_name = '%s', category_id = %s, location = '%s', capacity = %s, description = '%s' WHERE resource_id = %s" % (
            resource_name, category_id, location, capacity, description, resource_id)
        conn_mysql(update_sql)
        return redirect(url_for('manage_resource'))
    except Exception as e:
        print(f"修改资源信息时出错: {e}")
        return "修改资源信息失败，请稍后重试", 500


# 跳转预约界面
@app.route('/booking')
def booking_page():
    try:
        # 查询所有资源及其类别
        sql = """
              SELECT r.resource_id,
                     r.resource_name,
                     r.location,
                     r.capacity,
                     r.status,
                     r.description,
                     c.category_name
              FROM resources r
                       JOIN resource_categories c ON r.category_id = c.category_id
              ORDER BY c.category_id, r.resource_name \
              """
        # 使用 conn_mysql 函数执行查询
        resources = conn_mysql(sql)

        return render_template('booking.html', resources=resources)
    except Exception as e:
        print(f"查询资源信息时出错: {e}")
        # 可以返回错误页面或错误信息
        return "查询资源信息时出错，请稍后重试", 500


# 预约提交
@app.route("/verify", methods=['POST'])
def verify():
    username = request.form.get('username')
    password = request.form.get('password')
    resource_name = request.form.get('resource_name')
    booking_date = request.form.get('booking_date')  # 格式: 'YYYY-MM-DD'
    start_time = request.form.get('start_time')  # 格式: 'HH:MM:SS'
    end_time = request.form.get('end_time')  # 格式: 'HH:MM:SS'

    print("username:", username)
    print("resource_name:", resource_name)
    print("预约时间：", booking_date, start_time, end_time)

    # 1. 验证用户
    sql_user = f"SELECT * FROM users WHERE username = '{username}'"
    user_data = conn_mysql(sql_user)
    if not user_data:
        return jsonify({'success': False, 'message': '用户名不存在'})

    user = user_data[0]
    if user['password'] != password:
        return jsonify({'success': False, 'message': '密码错误'})

    user_id = user['user_id']

    # 2. 获取资源 ID
    sql_resource = f"SELECT * FROM resources WHERE resource_name = '{resource_name}'"
    res = conn_mysql(sql_resource)
    if not res:
        return jsonify({'success': False, 'message': '资源未找到'})

    resource = res[0]
    resource_id = resource['resource_id']

    # 3. 检查该资源在该时间段是否已被预约（booking 表）
    sql_check = f"""
        SELECT * FROM bookings 
        WHERE resource_id = {resource_id}
          AND booking_date = '{booking_date}'
          AND (
              (start_time < '{end_time}' AND end_time > '{start_time}')
          )
          AND booking_status IN ('pending', 'confirmed')
    """
    conflict = conn_mysql(sql_check)
    if conflict:
        return jsonify({'success': False, 'message': '该时间段资源已被预约'})

    # 4. 写入 booking 表（预约记录）
    insert_sql = f"""
        INSERT INTO bookings (resource_id, user_id, booking_date, start_time, end_time)
        VALUES ({resource_id}, {user_id}, '{booking_date}', '{start_time}', '{end_time}')
    """
    conn_mysql(insert_sql)

    return jsonify({'success': True, 'message': '预约成功'})


# 显示已被预约资源（学生和教师）
@app.route('/un_booking')
def un_booking_page():
    try:
        # 查询所有资源及其类别
        sql = """
              SELECT b.booking_id, b.resource_id, r.resource_name, b.user_id, b.start_time, b.end_time
              FROM bookings b
                       JOIN resources r ON b.resource_id = r.resource_id
              ORDER BY b.start_time \
              """

        # 使用 conn_mysql 函数执行查询
        resources = conn_mysql(sql)

        return render_template('un_booking.html', resources=resources)
    except Exception as e:
        print(f"查询资源信息时出错: {e}")
        # 可以返回错误页面或错误信息
        return "查询资源信息时出错，请稍后重试", 500


# 跳转取消预约用户验证界面
@app.route('/checkbookinguser', methods=['GET', 'POST'])
def cancel_booking_verify():
    if request.method == 'GET':
        booking_id = request.args.get('booking_id')
        resource_name = request.args.get('resource_name')
        if not booking_id or not resource_name:
            flash('取消预约信息缺失，请重新选择', 'error')
            return redirect(url_for('un_booking'))  # 你的预约列表页
        return render_template('checkbookinguser.html', booking_id=booking_id, resource_name=resource_name)

    elif request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        resource_name = request.form.get('resource_name')
        booking_id = request.form.get('booking_id')

        if not all([username, password, booking_id]):
            return jsonify({'success': False, 'message': '请填写完整信息'})

        # 验证用户身份
        user_sql = f"SELECT * FROM users WHERE username = '{username}'"
        users = conn_mysql(user_sql)
        if not users:
            return jsonify({'success': False, 'message': '用户名不存在'})
        user = users[0]
        if password != user['password'] or user.get('status') != 'active':
            return jsonify({'success': False, 'message': '密码错误或账户已禁用'})

        user_id = user['user_id']

        # 验证该用户是否有预约这个资源
        booking_sql = f"""
            SELECT * FROM bookings 
            WHERE booking_id = {booking_id} AND user_id = {user_id}
        """
        bookings = conn_mysql(booking_sql)
        if not bookings:
            return jsonify({'success': False, 'message': '未找到您预约该资源的记录'})

        # 删除预约记录
        delete_sql = f"DELETE FROM bookings WHERE booking_id = {booking_id} AND user_id = {user_id}"
        delete_result = conn_mysql(delete_sql)

        if not delete_result:
            return jsonify({'success': False, 'message': '取消预约失败，请稍后重试'})

        # 更新资源状态为available
        update_sql = f"UPDATE resources SET status = 'available' WHERE booking_id = {booking_id}"
        conn_mysql(update_sql)

        return jsonify({'success': True, 'message': '取消预约成功！'})


# 取消预约路由
@app.route('/cancel_booking', methods=['POST'])
def cancel_booking():
    try:
        # 获取表单数据
        data = request.json
        username = data.get('username')
        password = data.get('password')
        booking_id = data.get('booking_id')
        current_time = data.get('current_time')

        # 验证数据完整性
        if not all([username, password, booking_id]):
            return jsonify({
                'success': False,
                'message': '用户名、密码和预约ID为必填项'
            }), 400

        # 转换booking_id为整数
        try:
            booking_id = int(booking_id)
        except ValueError:
            return jsonify({
                'success': False,
                'message': '预约ID有误'
            }), 400

        # 1. 验证用户 credentials
        sql = "SELECT user_id FROM users WHERE username = %s AND password = %s"
        user = conn_mysql(sql, (username, password))

        if not user:
            return jsonify({
                'success': False,
                'message': '用户名或密码错误'
            }), 401

        user_id = user[0]['user_id']

        # 2. 验证预约记录存在且属于当前用户
        sql = """
              SELECT booking_id, booking_status, booking_date, start_time
              FROM bookings
              WHERE booking_id = %s
                AND user_id = %s \
              """
        booking = conn_mysql(sql, (booking_id, user_id))

        if not booking:
            return jsonify({
                'success': False,
                'message': '预约记录不存在或不属于当前用户'
            }), 404

        booking = booking[0]

        # 3. 检查是否可以取消预约（这里简化处理，不检查状态）
        # 可以根据需要添加状态检查逻辑
        # if booking['booking_status'] not in ['pending', 'confirmed']:
        #     return jsonify({
        #         'success': False,
        #         'message': '该预约状态不可取消'
        #     }), 400

        # 4. 检查是否超过取消时间（示例：预约开始前24小时可取消）
        try:
            booking_datetime = datetime.datetime.strptime(
                f"{booking['booking_date']} {booking['start_time']}",
                "%Y-%m-%d %H:%M:%S"
            )
            current = datetime.datetime.strptime(current_time, "%Y-%m-%d %H:%M:%S")

            # 计算时间差（这里设置为提前1小时可取消）
            time_difference = booking_datetime - current
            if time_difference.total_seconds() < 3600:  # 3600s
                return jsonify({
                    'success': False,
                    'message': '已超过取消时间，无法取消预约'
                }), 400

        except ValueError as ve:
            print(f"时间格式解析错误: {ve}")
            # 时间解析错误时，不阻止取消操作
            pass

        # 5. 删除预约记录
        sql = "DELETE FROM bookings WHERE booking_id = %s"
        result = conn_mysql(sql, (booking_id,))

        if result:
            return jsonify({
                'success': True,
                'message': '取消预约成功'
            })
        else:
            return jsonify({
                'success': False,
                'message': '取消预约失败，请稍后重试'
            }), 500

    except Exception as e:
        print(f"取消预约时出错: {e}")
        return jsonify({
            'success': False,
            'message': f'服务器内部错误: {str(e)}'
        }), 500


# 管理员
# 显示已被预约资源（管理员）
@app.route('/manage_booking')
def manage_booking_page():
    try:
        sql = """
              SELECT b.booking_id,
                     b.resource_id,
                     r.resource_name,
                     b.user_id,
                     b.start_time,
                     b.end_time,
                     u.username,
                     u.email,
                     u.contact_phone AS telephone
              FROM bookings b
                       JOIN resources r ON b.resource_id = r.resource_id
                       JOIN users u ON b.user_id = u.user_id
              ORDER BY b.start_time \
 \
              """
        bookings = conn_mysql(sql)
        return render_template('manage_booking.html', bookings=bookings)
    except Exception as e:
        print(f"查询资源信息时出错: {e}")
        return "查询资源信息时出错，请稍后重试", 500


# 跳转查看信息界面
@app.route('/checkuserinfor', methods=['GET', 'POST'])
def delete_booking():
    if request.method == 'GET':
        # 获取参数
        booking_id = request.args.get('booking_id')
        resource_name = request.args.get('resource_name')
        start_time = request.args.get('start_time')
        end_time = request.args.get('end_time')
        username = request.args.get('username')
        email = request.args.get('email')  # 注意这里是email，不是e_mail
        telephone = request.args.get('telephone')
        print('1收到的booking_id:', booking_id)

        if not booking_id or not resource_name:
            flash('预约信息缺失，请重新选择', 'error')
            return redirect(url_for('manage_booking'))

        return render_template('checkuserinfor.html',
                               booking_id=booking_id,
                               resource_name=resource_name,
                               start_time=start_time,
                               end_time=end_time,
                               username=username,
                               email=email,
                               telephone=telephone)

    # POST 请求，管理员删除预约记录
    elif request.method == 'POST':
        booking_id = request.form.get('booking_id')
        print('2收到的booking_id:', booking_id)

    if not booking_id:
        return jsonify({'success': False, 'message': '缺少预约ID'})

    try:
        booking_id_int = int(booking_id)
    except ValueError:
        return jsonify({'success': False, 'message': '预约ID格式错误'})

    # 查询预约是否存在
    check_sql = f"SELECT * FROM bookings WHERE booking_id = {booking_id_int}"
    booking_result = conn_mysql(check_sql)

    if not booking_result:
        return jsonify({'success': False, 'message': '预约记录不存在'})

    # 执行删除
    delete_sql = f"DELETE FROM bookings WHERE booking_id = {booking_id_int}"
    delete_result = conn_mysql(delete_sql)

    # 由于 conn_mysql 删除操作可能返回 None 或 影响行数，这里检查是否成功
    if delete_result is None:
        return jsonify({'success': False, 'message': '删除失败，请稍后再试'})

    return jsonify({'success': True, 'message': '预约记录已删除'})


if __name__ == '__main__':
    # 示例：查询资源类别
    # code1 = "SELECT * FROM resource_categories ORDER BY category_id"

    app.run(debug=True)