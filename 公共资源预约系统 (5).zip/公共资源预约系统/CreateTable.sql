-- 1. 用户表 - 存储管理员和普通用户信息
CREATE TABLE IF NOT EXISTS users
(
    user_id       INT PRIMARY KEY AUTO_INCREMENT,
    username      VARCHAR(50)                          NOT NULL UNIQUE,
    password      VARCHAR(100)                         NOT NULL,
    real_name     VARCHAR(50),
    contact_phone VARCHAR(20),
    email         VARCHAR(100),
    user_type     ENUM ('admin', 'student', 'teacher') NOT NULL,
    register_time DATETIME                    DEFAULT CURRENT_TIMESTAMP,
    status        ENUM ('active', 'inactive') DEFAULT 'active'
);

-- 2. 资源类别表 - 分类管理公共资源
CREATE TABLE IF NOT EXISTS resource_categories
(
    category_id   INT PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    description   VARCHAR(200),
    create_time   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3. 资源表 - 存储具体公共资源信息
CREATE TABLE IF NOT EXISTS resources
(
    resource_id   INT PRIMARY KEY AUTO_INCREMENT,
    resource_name VARCHAR(100) NOT NULL,
    category_id   INT,
    location      VARCHAR(200) NOT NULL,
    capacity      INT,
    status        ENUM ('available', 'occupied', 'maintenance') DEFAULT 'available',
    description   TEXT,
    create_time   DATETIME                                      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES resource_categories (category_id)
);

-- 4. 预约表 - 存储资源预约记录
CREATE TABLE IF NOT EXISTS bookings
(
    booking_id     INT PRIMARY KEY AUTO_INCREMENT,
    resource_id    INT,
    user_id        INT,
    booking_date   DATE NOT NULL,
    start_time     TIME NOT NULL,
    end_time       TIME NOT NULL,
    booking_status ENUM ('pending', 'confirmed', 'cancelled', 'completed') DEFAULT 'pending',
    booking_time   DATETIME                                                DEFAULT CURRENT_TIMESTAMP,
    notes          VARCHAR(200),
    FOREIGN KEY (resource_id) REFERENCES resources (resource_id),
    FOREIGN KEY (user_id) REFERENCES users (user_id),
    -- 确保同一资源在同一时间段没有冲突预约
    UNIQUE KEY uk_resource_time (resource_id, booking_date, start_time, end_time)
);

-- 5. 固定课程表 - 支持日期范围和多工作日的固定资源占用
CREATE TABLE IF NOT EXISTS fixed_courses
(
    course_id         INT PRIMARY KEY AUTO_INCREMENT,
    course_name       VARCHAR(100)                                                                       NOT NULL,
    resource_id       INT,
    -- 替换为支持多工作日的SET类型
    course_weekdays   SET ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') NOT NULL,
    start_time        TIME                                                                               NOT NULL,
    end_time          TIME                                                                               NOT NULL,
    -- 新增日期范围字段
    course_start_date DATE                                                                               NOT NULL,
    course_end_date   DATE                                                                               NOT NULL,
    semester          VARCHAR(50)                                                                        NOT NULL,
    description       VARCHAR(200),
    FOREIGN KEY (resource_id) REFERENCES resources (resource_id),
    -- 新增索引优化冲突检测查询
    INDEX idx_resource_date (resource_id, course_start_date, course_end_date)
);



